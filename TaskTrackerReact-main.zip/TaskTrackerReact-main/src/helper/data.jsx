const data = [
  {
    id: 1,
    task: "Study React Pre-Class Notes",
    day: "Dec 12th at 2:30pm",
    complete: false,
  },
  {
    id: 2,
    task: "Feed the Dog",
    day: "Dec 13th at 1:30pm",
    complete: true,
  },
  {
    id: 3,
    task: "Attend In-Class",
    day: "Dec 14th at 3:00pm",
    complete: false,
  },
  {
    id: 4,
    task: "Study React Pre-Class Notes",
    day: "Dec 12th at 2:30pm",
    complete: false,
  },
  {
    id: 5,
    task: "Feed the Dog",
    day: "Dec 13th at 1:30pm",
    complete: true,
  },
  {
    id: 6,
    task: "Attend In-Class",
    day: "Dec 14th at 3:00pm",
    complete: false,
  },
];
export default data;